Math Operations

A simple Python package providing basic arithmetic functions: sum and subtract.

Installation

pip install math_operations

Usage

```
from math_operations import sum_numbers, subtract_numbers

# Add two numbers
result1 = sum_numbers(5, 3)  # Returns 8

# Subtract two numbers
result2 = subtract_numbers(5, 3)  # Returns 2
```

License

MIT